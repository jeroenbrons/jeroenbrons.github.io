---
layout: page
title: About
permalink: /about/
---

Blog by Jeroen Brons, a student at the Hogeschool Utrecht (HBO-ICT)
